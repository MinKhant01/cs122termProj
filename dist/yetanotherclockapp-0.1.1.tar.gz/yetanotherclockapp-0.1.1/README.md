# Yet Another Clock App

A short description of the YACA project.